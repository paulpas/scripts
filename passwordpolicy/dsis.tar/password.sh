#!/bin/bash

if [[ $# -ne 2 ]]
then
                echo "Usage: password.sh <keyword> <IP>"
                echo "Example:  ./password.ksh foo 10.0.0.1"
                exit 0
fi



for i in `echo $1$2 | sha2 -512 -q | tr [a-z] [A-Z] | sed -e 's-.-& -2;s-.-& -5;s-.-& -8;s-.-& -11;s-.-& -14;s-.-& -17;s-.-& -20;s-.-& -23' | awk '{print $1" "$2" "$3" "$4" "$5" "$6" "$7" "$8}'`
do

string=`(echo ibase=16; echo $i%7E) | bc`
			if (( $string <= 40 ))
			then
				(( string = string + 41 )) # make sure it's a printable character and not a control character
			fi
			if (( $string == 92 ))
			then
				(( string = string + 1 )) # make sure it's a printable character and not a control character
			fi
			#if (( $string == 91 ))
			#then
			#	string="\$string" # make sure it's a printable character and not a control character
			#fi
char=`echo $string | awk '{printf("%c",$0)}'`
#/usr/bin/perl -ew "print ,$char\n";
echo -ne "$char"
done
echo
